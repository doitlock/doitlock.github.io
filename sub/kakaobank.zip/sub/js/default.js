$('.intro_img_slide').slick({
	dots: false,
	infinite: true,
	fade: true,
	cssEase: 'linear',
	autoplay: true,
	autoplaySpeed: 2000,
	arrows: false
});

$('.video_slide').slick({
	infinite: true,
	slidesToShow: 3,
	slidesToScroll: 1,
	arrows: true,
	dots: true,
	autoplay: true,
	autoplaySpeed: 2000
});

